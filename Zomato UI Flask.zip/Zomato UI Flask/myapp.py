# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 11:29:19 2019

@author: lalit
"""
    
from flask import render_template, Flask, request,url_for


from keras.models import load_model
import pickle 

import tensorflow as tf



graph = tf.get_default_graph()

with open(r'CountVectorizer','rb') as file:
    cv=pickle.load(file)
    print("\ncv loaded\n")
cla = load_model('zomato.h5')
cla.compile(optimizer='adam',loss='binary_crossentropy')
'''samp = "good girl"
samp2=cv.transform([samp])
xyz = cla.predict(samp2)
print("\nprediction is "+str(xyz)+"\n")
'''

app = Flask(__name__)

@app.route('/')
def landingpage():
    return render_template('Zomato.html')

@app.route('/tpredict')
@app.route('/', methods = ['GET','POST'])
def page2():
    if request.method == 'GET':
        img_url = url_for('static',filename = 'style/hello.png')
        return render_template('Zomato.html',url=img_url)
    if request.method == 'POST':
        topic = request.form['review']
        print("Hey " +topic)
        topic=cv.transform([topic])
        print("\n"+str(topic.shape)+"\n")
        with graph.as_default():
            y_pred = cla.predict(topic)
            print("pred is "+str(y_pred))
        if(y_pred > 0.5):
            img_url = url_for('static',filename = 'style/1_1.png')
            com = "Positive Tweet"
            topic = "Thanks for that wonderful review. Hope to keep up to your expectations and give our best."
        elif(y_pred < 0.5):
            img_url = url_for('static',filename = 'style/1_2.png')
            com = "Negative Tweet"
            topic = "We apologise and will work to improve the service and reach your expectations"
        else:
            img_url = url_for('static',filename = 'style/1_3.png')
            print(img_url)
            com = "Neutral Tweet"
            topic = "Ohh cool. You are trying to be Diplomatic."
        
        return render_template('Zomato.html',ypred = topic, com = com)
        



if __name__ == '__main__':
    app.run(host = 'localhost', debug = True , threaded = False)
    